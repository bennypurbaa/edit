[![asciicast](https://asciinema.org/a/MSN7xgLjdoYzF5npleL02tbDi.png)](https://asciinema.org/a/MSN7xgLjdoYzF5npleL02tbDi)

## Instagram Private Tools x toolsig v2.0.1
* Instagram Tools Based on NodeJS (This script or code was created by ccocot - Aldi Nugraha).
* bomliketarget,botlike,botlike2,dellallphoto,lnkauto,fnlauto,fftauto,fmlauto,fhtauto,fltauto,unfollall,unfollnotfollback.

[![Build](https://img.shields.io/badge/Codename_-_officialputuid-brightgreen.svg)]()
[![License](http://img.shields.io/:license-MIT-brightgreen.svg?style=flat)](LICENSE)
[![Badges](https://img.shields.io/badge/badges-%F0%9F%91%8D-brightgreen.svg)](https://shields.io/)

<p align="center">
    <a href="https://s.id/2nFcX"><img src="https://repository-images.githubusercontent.com/171382500/2d2ab080-f262-11e9-82b6-8c45d6164cdf" alt="Pict by I Putu Jaya Adi Pranata - officialputuid" /></a><br />
</p>

## Table of Contents
$ [Default or Basic Usage](#default-or-basic-usage)
$ [Information Tools](#information-tools)
$ [Warning](#warning)
$ [Update](#Update)
$ [Other Information](#Other-Information)
$ [My Social Media](#my-social-media)
$ [License](#license)

## Default or Basic Usage
	$ git clone https://github.com/officialputuid/toolsig.git
	$ cd toolsig
	$ unzip lib.zip
	$ node index.js

## Tutorial on Termux [ANDROID]
	$ pkg upgrade && pkg update
	$ pkg install git
	$ pkg install nodejs-lts
	$ git clone https://github.com/officialputuid/toolsig.git
	$ cd toolsig
	$ unzip lib.zip
	$ node index.js

## Tutorial on C9io/CodeAnywhere [WEB VERSION]
	$ Login c9.io/login | https://codeanywhere.com/login
	$ Select & Install Workspace + Package NodeJS
	$ nvm install 10.7.0 && nvm use 10.7.0 && nvm alias default 10.7.0
	$ git clone https://github.com/officialputuid/toolsig.git
	$ cd toolsig
	$ unzip lib.zip
	$ node index.js

## Tutorial on PC/LAPTOP [OS]
	# Download & Install Git for Windows (Link Download: https://s.id/2yGtu) *direct_link
	# Download & Install NodeJs for Windows (Versi 9.3.0)
	  -> 64bit (https://nodejs.org/dist/v9.3.0/node-v9.3.0-x64.msi) *direct_link_64bit
	  -> 32bit (https://nodejs.org/dist/v9.3.0/node-v9.3.0-x86.msi) *direct_link_32bit
	# Download File toolsig (https://s.id/2yGC6) & Extract the file
	# Right Click (Mouse/Touchpad) In "toolsig-master" Folder & Choose Git Bash Here!
	$ unzip lib.zip
	$ node index.js

## Information Tools
	$ bomliketarget.js	"LIKE/LOVE ALL MEDIA/POST TARGET"		[USING ITTYW]
	$ botlike.js	    	"LIKE/LOVE TIMELINE INSTAGRAM"			[5 TARGET/DELAY]	*ERROR
	$ botlike2.js	    	"LIKE/LOVE TIMELINE INSTAGRAM" 			[USING CURSOR]		*ERROR
	$ dellallphoto	    	"DELETE ALL MEDIA/POST INSTAGRAM" 		[USING ITTYW]
	$ lnktauto	    	"LIKE & COMMENT TARGET FOLLOWERS USER" 		[USING ITTYW] 		*NEW
	$ fnlauto	    	"FOLLOW & LIKE TARGET FOLLOWERS USER" 		[USING ITTYW] 		*NEW
	$ fftauto	    	"FOLLOW,LIKE,COMMENT TARGET FOLLOWER USER"	[USING ITTYW]
	$ fmlauto	    	"FOLLOW,LIKE,COMMENT TARGET MEDIA/POST" 	[USING ITTYW]
	$ fhtauto	    	"FOLLOW,LIKE,COMMENT TARGET HASTAG" 		[USING ITTYW]
	$ fltauto	    	"FOLLOW,LIKE,COMMENT TARGET LOCATION-ID" 	[USING CURSOR]
	$ unfollall 		"UNFOLOW ALL FOLLOWING INSTAGRAM" 		[USING ITTYW]
	$ unfollnotfollback	"UNFOLLOW NOT FOLLOWBACK INSTAGRAM" 		[USING ITTYW]

## Warning
	⚠ Use tools at your own risk.
	⚠ Use this Tool for personal use, not for sale.
	⚠ I am not responsible for your account using this tool.
	⚠ Make sure your account has been verified (Email & Telp).

## Update
	☑ Update 28/10/2019 Initial Release.
	☑ Now Equipped Information in every tool every time you use it.
	   
## Other Information
	☆ Aldi Nugraha a.k.a (Ccocot Ccocot).
	☆ Zerobyte.id - BC0DE.NET - NAONLAH.NET - WingKocoli.
	☆ Thank https://github.com/dilame/instagram-private-api for node module
	☆ Thank you for the help of all members SGB TEAM REBORN (https://www.sgb.or.id/).
	
## My Social Media
	☑ LINE		: https://line.me/ti/p/~officialputuid
	☑ INTAGRAM	: https://instagram.com/officialputuid
	☑ FACEBOOK	: https://facebook.com/officialputuid
	☑ TWITTER	: https://twitter.com/officialputuid
	☑ GITHUB	: https://github.com/officialputuid
	
## License
	☑ This project is licensed under MIT License 2017-2019. https://opensource.org/licenses/MIT.
